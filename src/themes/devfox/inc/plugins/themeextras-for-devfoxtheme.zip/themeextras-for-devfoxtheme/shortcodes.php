<?php


/*
 * Shortcode list and their calls - Depends on Visual Composer
 */
$shortcodeList = array(
	'cmt-current-year',
	'cmt-social-links',
	'cmt-site-tagline',
	'cmt-site-title',
	'cmt-site-url',
	'cmt-footermenu',
	'cmt-logo',
	'cmt-dropcap',
	'cmt-skincolor',
);
//if( function_exists('vc_map') && class_exists('WPBMap') ){
	foreach( $shortcodeList as $shortcode ){
		if( file_exists(get_template_directory() . '/inc/shortcodes/'.$shortcode.'.php') ){
			include_once( get_template_directory() . '/inc/shortcodes/'.$shortcode.'.php');
		} else {
			require_once CMTTE_DIR . 'shortcodes/'.$shortcode.'.php';
		}
	}
//}